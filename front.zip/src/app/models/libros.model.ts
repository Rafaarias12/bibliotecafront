export interface LibrosModel {
    id: number;
    titulo: string;
    autor: string;
    descripcion: string;
    categoria: string;
    
}
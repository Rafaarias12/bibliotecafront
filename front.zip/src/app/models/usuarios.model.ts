export interface UserModel {
    nombre: string;
    user: string;
    activo: number;
    perfil: string;
  }